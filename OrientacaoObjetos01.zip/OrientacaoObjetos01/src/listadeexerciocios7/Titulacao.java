package listadeexerciocios7;

public enum Titulacao {
	
	    MESTRE, DOUTOR;
	
}
